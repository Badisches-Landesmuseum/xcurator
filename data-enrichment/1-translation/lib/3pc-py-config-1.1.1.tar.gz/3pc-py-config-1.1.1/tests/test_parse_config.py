import os
import unittest

from py_config import read_app_config


class TestParseConfig(unittest.TestCase):
    TEST_PROJECT_PATH = os.path.join(os.path.dirname(__file__), "resources")
    TEST_CONFIG_PATH = os.path.join(TEST_PROJECT_PATH, "application.yml")

    def test_parse_app_config(self):
        config = read_app_config(self.TEST_CONFIG_PATH)

        self.assertIsNotNone(config)
        self.assertTrue("test" in config.keys())
        self.assertEqual(config['test']['config1'], 'default_value')
        self.assertEqual(config['test']['config3'], '')
        self.assertEqual(config['test']['config4'], 'http://localhost:1234')
        self.assertEqual(config['test']['config5'], 'super$')

    def test_parse_app_config_without_path(self):
        config = read_app_config(in_test_dir=True)

        self.assertIsNotNone(config)
        self.assertTrue("test" in config.keys())
        self.assertEqual(config['test']['config1'], 'default_value')
        self.assertEqual(config['test']['config3'], '')

    def test_with_custom_profile(self):
        os.environ['PROFILE'] = 'local'
        config = read_app_config(in_test_dir=True)
        self.assertEqual(config['test']['config1'], 'override')

    def test_parse_without_app_config(self):
        self.assertRaises(ValueError, read_app_config, "wrong/path")
