from pathlib import Path


def print_3pc_banner() -> None:
        print("""
                 _____
        |___ / _ __   ___
          |_ \| '_ \ / __|
         ___) | |_) | (__
        |____/| .__/ \___|
              |_| 3pc GmbH Neue Kommunikation

        """)


"""get project root path."""


def root_dir() -> Path:
    current_path = Path().absolute().parts

    if "tests" in current_path:
        index = current_path.index("tests")
    elif "src" in current_path:
        index = current_path.index("src")
    else:
        index = len(current_path)

    return Path(*current_path[0:index])


"""get model folder path or a relative file to it. the folder is supposed to be large ai files|folders which are not 
part of the code and located in rootDir/model."""


def model_dir(file_path: str = None):
    model_dir_path = Path(root_dir(), "model")
    return model_dir_path if not file_path else Path(model_dir_path, file_path)


"""get data folder path or a relative file to it. the folder is supposed to be large files which are not part of the 
code and located in rootDir/data."""


def data_dir(file_path: str = None):
    data_dir_path = Path(root_dir(), "data")
    return data_dir_path if not file_path else Path(data_dir_path, file_path)


"""get the ressource folder path or a relative file to it. switch between (src|tests) by the in_test_dir flag. 
Default: False = src"""


def resources_dir(file_path: str = None, in_test_dir=False):
    root = root_dir()
    resources = Path(root, "src/resources") if not in_test_dir else Path(root, "tests/resources")
    return resources if not file_path else Path(resources, file_path)
