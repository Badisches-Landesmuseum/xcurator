import logging
import os
import re
import sys
from typing import Dict, Any

import yaml

from py_config._resource_util import resources_dir


def read_app_config(config_path: str = None, in_test_dir=False) -> Dict[str, Any]:
    config_paths = []

    if config_path:
        config_paths.append(config_path)
    else:
        default_config_path = str(resources_dir("application.yml", in_test_dir=in_test_dir).resolve())
        config_paths.append(default_config_path)

    try:
        for file in os.listdir(os.path.join(sys.path[0], 'resources')):
            if file.startswith("application-" + os.environ['PROFILE']):
                file_path = os.path.join(sys.path[0], "resources/", file)
                config_paths.append(file_path)
    except:
        pass
    logging.debug("Try to load common config location: %s", config_paths)

    """
    Load a yaml configuration file and resolve any environment variables
    The environment variables must have !ENV before them and be in this format
    to be parsed: ${VAR_NAME}.
    E.g.:
    database:
        host: ${HOST}
        port: ${PORT:1234}
    app:
        log_path: '/var/${LOG_PATH}'
        something_else: '${AWESOME_ENV_VAR}/var/${A_SECOND_AWESOME_VAR:with default value}'
    :param str path: the path to the yaml file
    :param str data: the yaml data itself as a stream
    :param str tag: the tag to look for
    :return: the dict configuration
    :rtype: dict[str, T]
    """
    # pattern for global vars: look for ${word} or oprional with defaults ${word:default}
    pattern = re.compile('.*?\$\{(\w+)(:[\w|\\\/\-.,:$]+)*}')
    loader = yaml.SafeLoader

    # the tag will be used to mark where to start searching for the pattern
    # e.g. somekey: !ENV somestring${MYENVVAR}blah blah blah
    loader.add_implicit_resolver(" ", pattern, None)

    def merge_config_files(current, update):
        if (current is None):
            return update
        merge = current
        for key, value in update.items():
            for property, variable in value.items():
                merge[key][property] = variable
        return merge

    def constructor_env_variables(loader, node):
        """
        Extracts the environment variable from the node's value
        :param yaml.Loader loader: the yaml loader
        :param node: the current node in the yaml
        :return: the parsed string that contains the value of the environment
        variable
        """
        value = loader.construct_scalar(node)
        match = pattern.findall(value)  # to find all env variables in line
        if match:
            full_value = value

            for g in match:
                if len(g) > 1:
                    env_name = g[0]
                    default_value = g[1][1:]
                    match_str = f'{g[0]}{g[1]}'
                else:
                    env_name = g
                    default_value = ''
                    match_str = g

                full_value = full_value.replace(
                    f'${{{match_str}}}', os.environ.get(env_name, default_value)
                )
            return full_value
        return value

    loader.add_constructor(" ", constructor=constructor_env_variables)

    yml_data = None

    try:
        for path in config_paths:
            with open(path) as conf_data:
                yml_data_extended = yaml.load(conf_data, Loader=loader)
                yml_data = merge_config_files(yml_data, yml_data_extended)
        return yml_data
    except Exception as e:
        print(str(e))
        raise ValueError("No Config file (application*.yml found.")
