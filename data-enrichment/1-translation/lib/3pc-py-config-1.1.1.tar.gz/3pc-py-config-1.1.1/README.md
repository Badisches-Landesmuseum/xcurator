# Python Configuration

- **Author**: Sören Räuchle | 3pc GmbH
- **pip**: py-config

This library wraps the common application.yml configuration to support configuration
by environment variables with default values inside projects.
If there is no configuration, an empty config will be served.

## Where to put my 'application.yml' configuration files?

```raw
├── [APPLICATION NAME] (Our source code - name of the application)
│   └── resources (All static resources stored here)
│   │  ├──  application.yml  <---------------- Application Configuration File
│   │  ├──  application-[CUSTOM_FILE].yml <--- Application Custom File (Optional)
│   │  └──  application-local.yml  <---------- Application Local  File (Optional)
├── tests
│   └── ...
├── README.md
├── .gitignore
```

## Behaviour:

The parser converts the config to a directory of entries so you can easily grab them:

```
database:
    host: ${DB_HOST:localhost}
    port: 7283
    user ${DB_USER}
```

N.B. String in `${VARIABLE:string}` should not contain `:`, `;`, `=` symbols.

This config will be converted in:

#### No Environments are available! Config is using defaults if available:

```
config['database']['host'] = localhost
config['database']['host'] = 7283
config['database']['user'] =
```

This config will be converted in:

#### Environments are available! Config is using environments:

DB_HOST = 127.0.0.1
DB_USER = user

```
config['database']['host'] = 127.0.0.1
config['database']['host'] = 7283
config['database']['user'] = user
```

### Custom Profile

It is possible to configure a custom profile. A custom profile overrides the values of the `application.yml` profile.

To enable a custom profile:

1. create another application file with custom variables you wish to override.yml` for instance

application-local.yml:

```
server:
  port: 8082
```

2. define in the project environment variables of your project the profile you wish to activate: `PROFILE=local`

### Usage:

```python
from py_config import read_app_config

config = read_app_config()
```
